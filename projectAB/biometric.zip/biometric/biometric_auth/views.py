from django.shortcuts import render,HttpResponse
import json
import pyrebase
from .temp import  loadimg 
#here we add dictionary that stroes the data about  a database
config={
     "apiKey": "AIzaSyBDbta51BTIhCXEq5xwWQA9l7HoobEsB1g",
  "authDomain": "newproject-2b8c0.firebaseapp.com",
  "databaseURL": "https://newproject-2b8c0-default-rtdb.firebaseio.com",
  "projectId": "newproject-2b8c0",
  "storageBucket": "newproject-2b8c0.firebasestorage.app",
 " messagingSenderId": "201430695093",
  "appId": "1:201430695093:web:3206452e4bbf2fa49292fc",
  "measurementId": "G-83GCZQE8G3"
}
firebase=pyrebase.initialize_app(config)
authe = firebase.auth()
database=firebase.database()
def home(request):
    return render(request,"base.html")

# Create your views here.
def check_pass(request):
    #to check if the port is connected or not 
    cond=True#this is default till i connect my system with the fingerprint
    if cond:
        #add request to fetch the finger print
        print("finger print is fetched ")
        img=loadimg()
        # cv2.imshow("image",img)
    
    return render(request,"data.html")
    

    
def display(request):
    
    con =True
    if con :
        

              channel_name =database.child('data').child('name').get().val()
              channel_type =database.child('data').child('type').get().val()
              channel_sub =database.child('data').child('subscribers').get().val()
    
   
              return render(request,"firebase.html",{"channel_name":channel_name,
                                       "channel_type":channel_type,
                                       "channel_sub":channel_sub,
                                       })
        
    
